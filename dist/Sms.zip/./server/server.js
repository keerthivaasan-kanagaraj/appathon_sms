var twilio = require("twilio");
const { parse } = require('querystring');

exports = {

  events: [
    { event: "onAppInstall", callback: "onAppInstallHandler"},
    {event: "onExternalEvent", callback: "onExternalEventHandler" },
  ],

  onExternalEventHandler: function(payload) {
      console.log(payload);
      var string = JSON.stringify(payload);
      var parsed=JSON.parse(string);
      var iparams = parsed["iparams"];
      var data = parsed["data"];
      data=parse(data);
      console.log(data);
      const accountSid =iparams["account_sid"];
      const authToken = iparams["auth_token"];
      const t = twilio(accountSid, authToken);



      var message  = data["Body"].toUpperCase().split("-");
      
      var  main_menu = `Welcome to SMS portal.\n
      Thanks for reaching out. Type \n
      T for TICKET \n
      P for PRODUCT \n
      C for CONTRACT \n
      SR for Service Request`

      var  ticket_menu = `You have selected Ticket Menu.\n
      Type\n 
      TC for Creating a ticket\n
      TV for Viewing a ticket\n`
      var sr_menu = `You have selected Service Request Menu.
      Type\n
      SRCL to view all Service Item Categories\n
      SRCI-\"category_id\" to view all items in that category\n
      SI-\"item_id\" to display details about item\n
      `

      // var  product_menu = `You have selected Product Menu.\n
      // Type\n
      // PC for Creating a Product\n
      // PV for Viewing a Product\n`


      // var  contract_menu = `You have selected Contract Menu.\n
      // Type\n
      // CC for Creating a contract\n
      // CV for Viewing a contract\n`


      var tc_menu = `You have selected creating a new ticket.  \n Please Fill The Below Format without double quotes:\n tcreate-"email"-"subject"-"description" `
      var tv_menu = `You have selected viewing a ticket.  \n Please Fill The Below Format without double quotes:\n tview-"id"`



  switch(message[0])
  {
    case "T": sendMsg(ticket_menu);
               break;
    
    // case "P": sendMsg(product_menu);
    //            break;

    // case "C": sendMsg(contract_menu);
    //            break;         

    case "SR": sendMsg(sr_menu);break;

  
    case "TC": sendMsg(tc_menu); break;
    case "TV":sendMsg(tv_menu); break;
    
    // case "CC": sendMsg();break;
    // case "CV":sendMsg(); break;
    
    // case "PC": sendMsg();break;
    // case "PV":sendMsg(); break;

    case "TCREATE":createTicket();break;
    case "TVIEW":viewTicket();break;
    case "SRCL":allServiceCategory();break;
    case "SRCI":allServiceCategoryItems();break;
    case "SI":serviceItem();break;
    default: sendMsg(main_menu);
               break;  
    
  }
  function createTicket(){
    if(message.length==4&&message[0]=="TCREATE"){
    var m=`{
      "helpdesk_ticket":{
          "description":"${message[3]}",
          "subject":"${message[2]}",
          "email":"${message[1]}",
          "priority":1, "status":2, "source":2,"ticket_type":"Incident"
      },
      "cc_emails":"superman@marvel.com,avengers@marvel.com"
    }`;
    console.log(m);
    postapiCall("/helpdesk/tickets.json",m);
  }else{
    sendMsg("Error Mis-Matched Message Format");
    sendMsg(tc_menu);
  }
  }

  function viewTicket(){
    if(message.length==2&&message[0]=="TVIEW"){
    getapiCall("/helpdesk/tickets/"+message[1]+".json");
    }else{
      sendMsg("Error Mis-Matched Message Format");
      sendMsg(tv_menu);
    }
  }

  function allServiceCategory(){
    if(message.length==1&&message[0]=="SRCL"){
      getapiCall("/catalog/categories.json");
    }else{
      sendMsg("Error Mis-Matched Message Format");
      sendMsg("Type SRCL to view all service catrgories");
    }
  }

  function allServiceCategoryItems(){
    if(message.length==2&&message[0]=="SRCI"){
      getapiCall("/catalog/categories/"+message[1]+"/items.json");
    }else{
      sendMsg("Error Mis-Matched Message Format");
      sendMsg("Type SRCI-\"category_id\" to view all service catrgories items");
    }
  }

  function serviceItem(){
    if(message.length==2&&message[0]=="SI"){
      getapiCall("/catalog/items/"+message[1]+".json");
    }else{
      sendMsg("Error Mis-Matched Message Format");
      sendMsg("Type SI-\"item_id\" to view all service catrgories items");
    }
  }

  // function serviceRequestItem(){

  // }

      function getapiCall(path){
        var headers = {"Authorization": "Basic <%= iparam.agent_api_key %>",
        'Content-Type': 'application/json'};
        var options = { headers: headers};
        var url = "https://"+iparams["domain"]+path;
        $request.get(url, options)  
        .then (
        function(data) {
          var result= JSON.parse(JSON.stringify(data));
          result=JSON.parse(result["response"]);
          console.log(result);
          if(message[0]=="TVIEW"){
            sendMsg("For id: "+message[1]+" \nSubject: "+result["helpdesk_ticket"]["subject"]+" \nDescription: "+result["helpdesk_ticket"]["description"]);
          }else if(message[0]=="SRCL"){
            var temp="category id => category name\n";
            result.forEach(function(item){
              temp+=item.id+"=>"+item.name+", \n";
            });
            sendMsg("Your Categories List:  \n"+temp);
          }else if(message[0]=="SRCI"){
            var temp="Item id => Item name\n";
            result.forEach(function(item){
              temp+=item.display_id+"=>"+item.name+", \n";
            });
            console.log("---------------------")
            console.log(temp)
            sendMsg("Your Category Items List:  \n"+temp);
          }else if(message[0]=="SI"){
            sendMsg("For id: "+message[1]+" \nName: "+result["catalog_item"]["name"]+" \nDescription: "+result["catalog_item"]["description"]);
          }
        },
        function(error) {
          sendMsg("Error");
          sendMsg(main_menu);
          console.log(error); 
        });
      }
      function postapiCall(path,msgjson){
        var headers = {"Authorization": "Basic <%= iparam.agent_api_key %>",
        'Content-Type': 'application/json'};
        var options = { headers: headers,body:msgjson};
        var url = "https://"+iparams["domain"]+path;
        $request.post(url, options)  
        .then (
        function(data) {
          var result= JSON.parse(JSON.stringify(data));
          result=JSON.parse(result["response"]);
          console.log(result);
          if(message[0]=="TCREATE"){
            sendMsg("Ticket Successfully Created Your Ticket ID: "+result["item"]["helpdesk_ticket"]["display_id"]+"\n To View Tickets Please Fill The Below Format without double quotes:\n tview-\"id\"");
           }
        },
        function(error) {
          sendMsg("Error");
          sendMsg(main_menu);
          console.log(error); 
        });
      }


    

      function sendMsg(msg){
      return t.messages.create({
        body: msg,
        to: data["From"],
        from: data["To"]
      },function(error,message){
        if(!error){
          console.log("Success"+message);
        }else{
          sendMsg("Error");
          sendMsg(main_menu);
          console.log(error);
        }
      });
    }
      
  },

  onAppInstallHandler: function(payload) {
    var string = JSON.stringify(payload);
    var iparams = JSON.parse(string)["iparams"];
    generateTargetUrl()
    .then(function(url) {
          //Include API call to the third party to register your webhook
          const Sms_client = twilio(iparams["account_sid"], iparams["auth_token"]);
          Sms_client.messaging.services
                    .create({friendlyName: iparams["messaging_service_name"], inboundRequestUrl: url})
                    .then(service => console.log(service.sid))
                    .done();
                    
    })
    .fail(function(err) {
        // Handle error
        console.log("kkvout"+err);
        renderData({
          message: 'Error generating target Url'
        });
    })
    renderData();
  }

};